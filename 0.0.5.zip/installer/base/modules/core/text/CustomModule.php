<?php
	defined("CRISPAGE") or die("Application must be started from index.php!");

	class CustomModule extends Module {
		public function render() {
			if (!isset($this->settings["content"])) return;

			echo "<div class=\"module CustomModule module-$this->id\">\n";
			echo $this->settings["content"] . "\n";
			echo "</div>";
		}
	}
?>
