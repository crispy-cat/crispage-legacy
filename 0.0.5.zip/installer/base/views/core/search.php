<?php
	defined("CRISPAGE") or die("Application must be started from index.php!");

?>
