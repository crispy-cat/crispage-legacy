<?php
	defined("CRISPAGE") or die("Application must be started from index.php!");

	class Randomizer {
		public const RCHARS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ./";

		public static function randomString(int $length = 0, int $base = 0) : string {
			if ($base < 1) $base = 64;
			if ($length < 1) $length = 64;
			$str = "";
			for ($i = 0; $i < $length; $i++)
				$str .= Randomizer::RCHARS[random_int(0, $base - 1)];
			return $str;
		}
	}
?>
