<?php
	defined("CRISPAGE") or die("Application must be started from index.php!");
	require_once Config::APPROOT . "/backend/header.php";

	if (!isset($app->request->query["delete_id"]))
		$app->redirect(Config::WEBROOT . "/backend/articles/list?me=No ID Specified");

	if (!$app->content->existsArticle($app->request->query["delete_id"]))
		$app->redirect(Config::WEBROOT . "/backend/articles/list?me=Article does not exist");

	$article = $app->content->getArticle($app->request->query["delete_id"]);

	if ($article->author == $app->session->getCurrentSession()->user) {
		if (!$app->users->userHasPermissions($app->session->getCurrentSession()->user, UserPermissions::MODIFY_ARTICLES_OWN))
			$app->redirect(Config::WEBROOT . "/backend/articles/list?me=You do not have permission to delete articles");
	} else {
		if (!$app->users->userHasPermissions($app->session->getCurrentSession()->user, UserPermissions::MODIFY_ARTICLES))
			$app->redirect(Config::WEBROOT . "/backend/articles/list?me=You do not have permission to delete others' articles");
	}

	if (isset($app->request->query["confirm"]) && $app->request->query["confirm"]) {

		$app->content->deleteArticle($article->id);
		$app->redirect(Config::WEBROOT . "/backend/articles/list?ms=Article deleted.");
	}

	$app->vars["article_title"] = htmlentities($article->title);

	$app->page->setTitle("Delete {$app->vars["article_title"]}");

	$app->page->setContent(function($app) {
?>
		<div id="main" class="page-content">
			<div class="row">
				<div class="col">
					<h1>Delete '<?php echo $app->vars["article_title"]; ?>'</h1>
					<p>Are you sure you want to delete this article? This action cannot be undone!</p>
					<form class="d-flex">
						<input type="hidden" name="delete_id" value="<?php echo $app->request->query["delete_id"]; ?>" />
						<input type="hidden" name="confirm" value="1" />
						<a class="btn btn-primary me-2" href="<?php echo Config::WEBROOT; ?>/backend/articles/list">Back</a>
						<button class="btn btn-danger" type="submit">Delete</button>
					</form>
				</div>
			</div>
		</div>
<?php
	});

	$app->events->trigger("backend.view.articles.delete", $app->request->query["delete_id"]);

	$app->renderPage();
?>
