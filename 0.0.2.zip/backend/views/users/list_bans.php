<?php
	defined("CRISPAGE") or die("Application must be started from index.php!");
	require_once Config::APPROOT . "/backend/header.php";

	if (!isset($app->request->query["user_id"]))
		$app->redirect(Config::WEBROOT . "/backend/users/list?me=No ID specified");

	$user = $app->users->getUser($app->request->query["user_id"]);
	if (!$user)
		$app->redirect(Config::WEBROOT . "/backend/users/list?me=User does not exist");

	$app->page->setTitle("Bans");

	$app->vars["show"] = $app->request->query["show"] ?? 15;
	$app->vars["page"] = $app->request->query["page"] ?? 1;

	$bans = $app->bans->getBans($user->id);

	$app->vars["npages"] = Paginator::numPages($bans, (is_numeric($app->vars["show"])) ? $app->vars["show"] : 0);

	if (is_numeric($app->vars["show"]))
		$app->vars["bans"] = Paginator::paginate($bans, $app->vars["show"], (is_numeric($app->vars["page"])) ? $app->vars["page"] : 1);
	else
		$app->vars["bans"] = $bans;

	$app->page->setContent(function($app) {
?>
		<div id="main" class="page-content">
			<div class="row">
				<div class="col-12 col-md-2">
					<h1>User Bans</h1>
					<p>'<?php echo $app->request->query["user_id"]; ?>'</p>
					<span>Show only:</span>
					<form class="d-flex">
						<select class="form-select ms-2" name="show">
							<option value="15">15</option>
							<option value="30">30</option>
							<option value="60">60</option>
							<option value="120">120</option>
							<option value="240">240</option>
							<option value="480">480</option>
							<option value="all">All</option>
						</select>
						<button class="btn btn-primary ms-2" type="submit">Go</button>
					</form>
				</div>
				<div class="col-12 col-md-10">
					<div style="float: right;">
						<div class="btn-group mt-4 mb-2 d-block ms-auto">
							<a class="btn btn-warning" href="<?php echo Config::WEBROOT; ?>/backend/users/ban_user?user_id=<?php echo $app->request->query["user_id"]; ?>" style="width: 90px;">New Ban</a>
							<a class="btn btn-warning" href="<?php echo Config::WEBROOT; ?>/backend/users/unban_user?user_id=<?php echo $app->request->query["user_id"]; ?>" style="width: 110px;">Unban User</a>
						</div>
						<?php
							$baseurl = Config::WEBROOT . "/backend/users/list_bans?show=" . (($app->vars["show"]) ? $app->vars["show"] : "all") . "&page=";
							RenderHelper::renderPagination($baseurl, $app->vars["npages"], $app->vars["page"] ?? 1);
						?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<?php if (count($app->vars["bans"])) { ?>
						<table class="table table-striped">
							<thead>
								<tr>
									<th>Expires</th>
									<th>Reason</th>
									<th>Created</th>
									<th>Modified</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($app->vars["bans"] as $ban) { ?>
									<tr>
										<td><?php echo date($app->getSetting("date_format", "Y-m-d"), $ban->expires); ?></td>
										<td><?php echo htmlentities($ban->reason); ?></td>
										<td><?php echo date($app->getSetting("date_format", "Y-m-d"), $ban->created); ?></td>
										<td><?php echo date($app->getSetting("date_format", "Y-m-d"), $ban->modified); ?></td>
										<td>
											<a class="btn btn-danger btn-sm" href="<?php echo Config::WEBROOT; ?>/backend/users/delete_ban?delete_id=<?php echo $ban->id; ?>"><i class="bi bi-trash"></i> Delete</a>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					<?php } else { ?>
						<p>No users match your criteria!</p>
					<?php } ?>
				</div>
			</div>
		</div>
<?php
	});

	$app->events->trigger("backend.view.users.list");

	$app->renderPage();
?>
