<?php
	define("VERSION", "0.0.1 alpha")
	define("INSTALLER", dirname(__FILE__));
	define("ROOT", dirname(INSTALLER));
	define("WINSTALLER", dirname($_SERVER["PHP_SELF"]));

	if (isset($_REQUEST["page"])) {
		$page = true;
		$name = $_REQUEST["page"];
	} elseif (isset($_REQUEST["script"])) {
		$page = false;
		$name = $_REQUEST["script"];
	} else {
		$page = true;
		$name = "default";
	}

	if ($page) {
		$file = INSTALLER . "/pages/$name.php";
		if (!file_exists($file)) die("Page not found");
		require_once $file;
	} else {
		$file = INSTALLER . "/scripts/$name.php";
		if (!file_exists($file)) die("Script not found");
		require_once $file;
	}
?>
